# Design System

Source: Figma / Perspective / Variables (node 141:805)

## Colors (`UI/Theme/DesignTokens.swift`)

### Neutrals (AppColors.Neutral)
9-step grayscale from near-white to near-black:

| Token | Hex | Usage |
|-------|-----|-------|
| n50 | #FAFAFA | Light backgrounds |
| n100 | #F5F5F5 | Card surfaces (light), tab tint |
| n200 | #E5E5E5 | Dividers (light), tag text |
| n300 | #D4D4D4 | Placeholders (light) |
| n400 | #A1A1A1 | Meta text (light) |
| n500 | #737373 | Tertiary text (light) |
| n600 | #525252 | Body text (light) |
| n700 | #404040 | Secondary text (light), centre tag text |
| n800 | #262626 | Primary text (light) |
| n900 | #171717 | Card surfaces (dark), backgrounds (dark) |
| n950 | #0A0A0A | Feed/page background (dark) |

### Spectrum Colors (AppColors.Spectrum)
Static Figma token colors for tags and charts:

| Position | Hex | Constant |
|----------|-----|----------|
| Extrême-gauche | #963636 | eGauche |
| Gauche | #D96559 | gauche |
| Centre-gauche | #ECACAC | centreGauche |
| Centre | #FFFFFF | centre |
| Centre-droite | #ECACAC | centreDroite |
| Droite | #4778E9 | droite |
| Extrême-droite | #2C46A0 | eDroite |

### Adaptive Colors (AppColors.Adaptive in `AdaptiveTokens.swift`)
Semantic tokens using `UIColor { traitCollection in }` for light/dark:

| Token | Light | Dark | Usage |
|-------|-------|------|-------|
| feedBackground | n50 | n950 | Feed scroll background |
| background | n50 | n950 | Page-level background |
| cardSurface | n100 | n900 | Cards on feed |
| detailSurface | n100 | n900 | Cards on detail page |
| divider | n200 | n800 | 1pt separator lines |
| textPrimary | n800 | n50 | Large titles, prominent text |
| textSecondary | n700 | n200 | Card titles |
| textBody | n600 | n300 | Paragraphs, body text |
| textTertiary | n500 | n400 | Captions, section headers |
| textMeta | n400 | n500 | Source names, counts, metadata |
| placeholder | n300 | n600 | Loading skeletons |
| stroke | black@8% | white@10% | Component borders |

### PoliticalLean Adaptive Colors (in `PoliticalLean.swift`)
Each lean position has an adaptive `color` property (brightened ~20% in dark mode for legibility). Used for spectrum visualizations. Separate from `spectrumColor` which is the static Figma token.

### OwnerType Colors (in `Source.swift`)
Each OwnerType has adaptive colors (e.g. billionaire = gold, public = blue, independent = green, etc.).

## Typography (`UI/Theme/Typography.swift`)

10 font scales as `Font` static properties:

| Scale | Size | Weight |
|-------|------|--------|
| appLargeTitle | 28pt | heavy |
| appTitle1 | 24pt | bold |
| appTitle2 | 18pt | bold |
| appTitle3 | 18pt | semibold |
| appHeadline | 17pt | semibold |
| appBody | 17pt | regular |
| appSubheadline | 15pt | regular |
| appFootnote | 14pt | medium |
| appCaption1 | 13pt | semibold |
| appCaption2 | 11pt | regular |

Custom fonts registered at launch: **Geist Variable**, **BarlowCondensed Bold**, **BarlowCondensed SemiBold** (via CoreText in `PerspectiveApp.init()`). Typography scale uses `.system()` — custom fonts used directly where needed.

## Spacing (`AppSpacing`)

4pt baseline grid:

| Token | Value |
|-------|-------|
| xs | 4pt |
| s | 8pt |
| st | 12pt |
| m | 16pt |
| ml | 20pt |
| l | 24pt |
| xl | 32pt |
| xxl | 48pt |
| xxxl | 64pt |

## Corner Radii (`AppRadius`)

| Token | Value |
|-------|-------|
| xs | 4pt |
| s | 6pt |
| st | 8pt |
| m | 10pt |
| ml | 12pt |
| l | 16pt |
| xl | 20pt |
| pill | 9999pt |

## Shared UI Components

- **LeanTagView** — `.capsule` (full label) or `.rounded` (short label) style
- **SourceAvatarView** — AsyncImage logo or initial fallback, configurable size
- **SourceCard** — Row: avatar + name + owner + lean tag
- **CardPressStyle** — Custom ButtonStyle with scale + opacity animation
- **.cardSurface()** modifier — background fill + clipShape + stroke
- **.perspectiveNavigationBar()** modifier — shared navigation bar appearance
