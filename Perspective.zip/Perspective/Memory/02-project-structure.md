# Project Structure

```
Perspective/
├── App/
│   ├── PerspectiveApp.swift          # @main entry point. Font registration (Geist, BarlowCondensed) via CoreText. Notification auth request. Splash overlay. Color scheme from @AppStorage("colorSchemeRaw"). Scene phase triggers notification check.
│   ├── RootView.swift                # TabView root. iOS 18 Tab API with legacy fallback. Injects @Environment: SessionState, BookmarkStore, ReadingHistoryStore. Onboarding fullScreenCover. Notification deep-link switches tab.
│   ├── SessionState.swift            # @Observable @MainActor. In-memory story counter (storiesOpened). Owns StoreManager. isPremium (StoreKit + DEBUG override). shouldShowPaywall at 5 opens.
│   ├── BookmarkStore.swift           # @Observable @MainActor. UserDefaults JSON persistence of [Story]. toggle(), isBookmarked(). ISO8601 date coding.
│   └── SplashView.swift              # Launch splash animation
│
├── Config/
│   └── AppConfig.swift               # supabaseURL, supabaseAnonKey, StoreKit product IDs. Anon key is public, protected by RLS.
│
├── Features/
│   ├── Feed/
│   │   ├── FeedView.swift            # Root feed: hero card + aggregate coverage bar + daily brief carousel + paginated story list
│   │   ├── FeedViewModel.swift       # @Observable @MainActor. 48h in-memory cache. Protocol-injected repo. Computed: stories (≥2 articles), cetteSemanineHero, briefStories, feedStories, aggregateCoverage.
│   │   ├── StoryCardView.swift       # 3 variants: big, small, extended
│   │   ├── DailyBriefCardView.swift  # Compact 250px card for carousel
│   │   └── DailyBriefSectionView.swift # Horizontal 2-story brief container
│   │
│   ├── Story/
│   │   ├── StoryDetailView.swift     # Full story: header, summary, thread, articles, ownership
│   │   ├── StoryDetailViewModel.swift # @Observable @MainActor. triggerSummaryGeneration() calls Edge Function, waits 3s, refetches story.
│   │   ├── StoryThreadView.swift     # Chronological timeline grouped by day, opens in-app webview
│   │   ├── SpectrumSummaryView.swift # AI summary display or skeleton loader
│   │   ├── PaywallView.swift         # Full-screen subscription UI (StoreKit 2)
│   │   ├── AnalyzedArticleCard.swift # Article card with LeanTagView + SourceAvatarView
│   │   └── ArticleBrowserView.swift  # WebKit in-app reader, auto-hide toolbar, records reading history after 2s
│   │
│   ├── Discover/
│   │   ├── DiscoverView.swift        # Search + topic filter chips
│   │   └── DiscoverViewModel.swift   # @Observable @MainActor. Server-side topic filter via Supabase contains(). Client-side text search. Pagination with loadMore().
│   │
│   ├── Alertes/
│   │   ├── AlertesView.swift         # Notification list with deep-link navigation to StoryDetailView
│   │   └── AlertesViewModel.swift    # Loads notifications via NotificationManager, fetchStory for navigation
│   │
│   ├── Source/
│   │   ├── SourceDetailView.swift    # Source info: logo, lean, owner, recent articles
│   │   └── SourcesView.swift         # All sources list with embedded @MainActor SourcesViewModel
│   │
│   ├── Profile/
│   │   └── ProfileView.swift         # Profile menu: Saved, Sources
│   │
│   ├── Saved/
│   │   └── SavedView.swift           # Bookmarked stories list
│   │
│   ├── Onboarding/
│   │   └── OnboardingView.swift      # First-launch flow. Sets hasCompletedOnboarding AppStorage.
│   │
│   └── Settings/
│       ├── SettingsView.swift        # Notifications, theme, profile, about, legal, DEBUG premium toggle
│       └── MySpectrumView.swift      # Reading history: spectrum bar + breakdown list + reset
│
├── Core/
│   ├── Models/
│   │   ├── Story.swift               # id, title, articles, coverage, spectrumSummary, lastUpdatedAt. Custom decoder filters to isPrimary articles only.
│   │   ├── Article.swift             # id, title, imageURL, publishedAt, url, source (via join). CodingKey "sources" maps to source field.
│   │   ├── Source.swift              # id, name, logoURL, politicalLean (1-7), ownerName, ownerType. Computed lean: PoliticalLean?.
│   │   ├── CoverageStats.swift       # 7-point lean counts + pcts. FiveBucketCoverage. Custom decodeDouble for PostgreSQL Int→Double. aggregate(), coverageNarrative, dominantLean, coversFullSpectrum.
│   │   ├── PoliticalLean.swift       # Enum 1-7. spectrumColor, color (adaptive), tagTextColor, label, shortLabel. Figma token colors.
│   │   ├── AppError.swift            # networkUnavailable, serverError, dataCorrupted, unknown(String). Sendable + Equatable. Maps NSURLError + DecodingError.
│   │   ├── PushNotification.swift    # id, title, body, storyCount, storyId, sentAt
│   │   ├── StoryTopic.swift          # Enum: tout, politique, economie, societe, international, environnement, justice, culture. filterValue for Supabase.
│   │   └── PreviewData.swift         # #if DEBUG mock data for SwiftUI previews
│   │
│   ├── Protocols/
│   │   └── RepositoryProtocols.swift # StoryRepositoryProtocol (fetchFeed, fetchStory), SourceRepositoryProtocol (fetchAllSources, fetchSource, fetchRecentArticles). Both Sendable.
│   │
│   ├── Services/
│   │   ├── SupabaseService.swift     # Singleton. SupabaseClient init with custom JSONDecoder (ISO8601 + fractional seconds + date-only fallback).
│   │   ├── StoreManager.swift        # @Observable @MainActor. StoreKit 2: loadProducts, purchase, restore, transaction listener. monthlyProduct/annualProduct helpers.
│   │   ├── NotificationManager.swift # @Observable @MainActor singleton. UNUserNotificationCenter delegate. Polls Supabase notifications table. Schedules local notifications. pendingStoryID for deep-link.
│   │   └── ReadingHistoryStore.swift  # @Observable @MainActor. Tracks [Int] lean values in UserDefaults. record(lean:), reset(), breakdown computed.
│   │
│   ├── Repositories/
│   │   ├── StoryRepository.swift     # StoryRepositoryProtocol. fetchFeed: select with joins, topic filter, pagination. fetchStory: single by ID.
│   │   └── SourceRepository.swift    # SourceRepositoryProtocol. fetchAllSources, fetchSource, fetchRecentArticles.
│   │
│   └── Utilities/
│       ├── Log.swift                 # os.Logger: feed, story, repository, store, notification, general
│       └── DateFormatting.swift      # Date.relativeToNowFrench() — cached RelativeDateTimeFormatter
│
└── UI/
    ├── Components/
    │   ├── LeanTagView.swift         # .capsule (full label) or .rounded (short label) lean tag
    │   ├── SourceAvatarView.swift    # Source logo or initial fallback, configurable size
    │   ├── SourceCard.swift          # Source row: avatar + name + owner + lean tag
    │   ├── PaywallBannerView.swift   # Soft paywall bottom banner (dismissible)
    │   ├── CoverageTagsView.swift    # Top 2 coverage tags by percentage
    │   ├── CoverageChartView.swift   # Political coverage bar chart (per-story, full legend)
    │   ├── FeedCoverageBarView.swift # Compact aggregate coverage bar + narrative for feed
    │   ├── OwnershipBreakdownView.swift # Media ownership breakdown
    │   ├── ArticlesSection.swift     # Article list grouped by lean (legacy, uses system fonts)
    │   ├── OwnershipSection.swift    # Owner groups with info sheet (legacy, uses system fonts)
    │   ├── CardPressStyle.swift      # Custom ButtonStyle: scale + opacity on press
    │   └── SwipeBackEnabler.swift    # Native swipe-back documentation
    │
    ├── Modifiers/
    │   ├── CardSurface.swift         # .cardSurface(fill:radius:) — background + clipShape + stroke
    │   └── NavigationBarStyle.swift  # .perspectiveNavigationBar() — shared nav bar appearance
    │
    └── Theme/
        ├── Typography.swift          # 10 Font scales: appLargeTitle (28pt heavy) → appCaption2 (11pt regular)
        ├── DesignTokens.swift        # AppColors (Neutral 9-step, Spectrum 7-point), AppSpacing (4pt grid), AppRadius, Color(hex:) extension
        └── AdaptiveTokens.swift      # AppColors.Adaptive — semantic light/dark tokens via UIColor trait collections
```
