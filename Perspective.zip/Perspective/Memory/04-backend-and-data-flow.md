# Backend & Data Flow

## Supabase Configuration

- **Project ref:** `lsznkuiaowesucmxwwfi`
- **URL:** `https://lsznkuiaowesucmxwwfi.supabase.co`
- **Auth:** Anon key (public, protected by RLS). Stored in `Config/AppConfig.swift`.
- **Client init:** `SupabaseService.swift` — singleton with custom `JSONDecoder` handling ISO8601 + fractional seconds + date-only formats.

## Database Schema

| Table | Key Columns |
|-------|-------------|
| `stories` | id, title, summary, first_published_at, last_updated_at, topic_tags (text[]), is_featured, spectrum_summary (jsonb), summary_generated_at |
| `articles` | id, title, url, summary, image_url, published_at, fetched_at, source_id (FK), story_id (FK), raw_keywords, click_count, is_primary |
| `sources` | id, name, url, rss_url, logo_url, is_active, political_lean (1-7), owner_name, owner_type |
| `story_coverage_view` | story_id (FK), lean_1-7_count, lean_1-7_pct, total_count |
| `notifications` | id, title, body, story_count, story_id (FK to stories, added 2026-05-28), sent_at |

## PostgREST Queries (from Repositories)

### StoryRepository
- **fetchFeed:** `GET /rest/v1/stories` with `select: "*, story_coverage_view(*), articles!inner(*, sources(*))"`. Optional `contains("topic_tags", value: "{topic}")`. Ordered by `last_updated_at DESC, id ASC`. Paginated via `range(from:to:)`.
- **fetchStory:** Same select, filtered by `eq("id", value: id)`, `limit(1)`.

### SourceRepository
- **fetchAllSources:** `GET /rest/v1/sources` where `is_active = true`, ordered by `political_lean ASC`.
- **fetchSource:** By ID, `limit(1)`.
- **fetchRecentArticles:** `GET /rest/v1/articles` where `source_id = id`, ordered by `published_at DESC`, limited.

## Edge Functions

| Function | Trigger | What It Does |
|----------|---------|--------------|
| `refresh-stories` | Scheduled via `pg_cron` every 4h (job: `refresh-stories-every-4-hours`) | Phase 1: ingests RSS. Phase 2: clusters articles into stories. |
| `generate-spectrum-summary` | On-demand from iOS (`StoryDetailViewModel`) | Receives `story_id`, calls Gemini, returns multi-perspective summary. Stored in `stories.spectrum_summary` jsonb. |
| `ingest-rss` | Legacy standalone | RSS ingester (superseded by refresh-stories Phase 1) |
| `cluster-stories` | Legacy standalone | Clustering (superseded by refresh-stories Phase 2) |

## AI Summary Flow

1. User opens `StoryDetailView` → `StoryDetailViewModel.triggerSummaryGeneration()` checks if `spectrumSummary == nil`
2. Invokes `generate-spectrum-summary` Edge Function with `story_id`
3. Waits 3 seconds (`Task.sleep`)
4. Refetches story via `repository.fetchStory(id:)` to get updated `spectrumSummary`
5. UI shows `SpectrumSummaryView` — skeleton loader while nil, perspectives list when available

## Data Persistence Summary

| Data | Storage | Persistence |
|------|---------|-------------|
| Stories, articles, sources | Supabase PostgreSQL | Server-side |
| AI summaries | `stories.spectrum_summary` jsonb | Server-side |
| Subscription status | Apple StoreKit 2 | Apple servers |
| Bookmarks | UserDefaults `bookmark_store_stories` (JSON-encoded `[Story]`) | Local, device-only |
| Reading history | UserDefaults `readingHistory` (`[Int]` lean values) | Local, device-only |
| Theme setting | `@AppStorage("colorSchemeRaw")` | Local |
| Onboarding flag | `@AppStorage("hasCompletedOnboarding")` | Local |
| Last notification ID | UserDefaults `lastNotificationId` | Local |
| Stories opened counter | In-memory (`SessionState.storiesOpened`) | Ephemeral, resets per launch |

**No Core Data. No SwiftData. No Realm. No local database.**

## Cron Job (`pg_cron` + `pg_net`)

- Job name: `refresh-stories-every-4-hours`
- Schedule: `0 */4 * * *` (at hours 0, 4, 8, 12, 16, 20 UTC daily)
- Mechanism: `pg_cron` calls `net.http_post()` to invoke the `refresh-stories` Edge Function
- Auth: reads `project_url` and `anon_key` from `vault.decrypted_secrets`
- **Vault secrets required:** Both `project_url` (Supabase URL) and `anon_key` (anon JWT) must exist in Vault. Without them the job fails with null URL/Authorization.

### Notification Trigger

- `notify_new_stories()` — PostgreSQL trigger function on `stories` table, fires `AFTER INSERT FOR EACH STATEMENT`
- Finds the top story (most articles) from the last 5 minutes
- Inserts into `notifications` with `story_id` linked to that top story
- Rate-limited: only fires if last notification was >1 hour ago

## Known Data Quirks

1. **PostgreSQL integer JSON:** `lean_*_pct` values of 0.0 or 1.0 serialize as integers in JSON. `CoverageStats` has a custom `decodeDouble` that tries `Double` first, then `Int`.
2. **Gemini summary format:** `spectrum_summary.perspectives[].summary` can be a `String` OR `[String]`. `SpectrumPerspective` decoder handles both (joins array with space).
3. **Date formats:** Supabase returns both `timestamptz` ("2026-03-17T10:30:00+00:00") and date-only ("2026-03-17"). Custom decoder in `SupabaseService` handles both. All Supabase queries must use `.execute().value` (not manual JSONDecoder) to leverage this.
4. **Feed cache:** In-memory only (48h TTL in FeedViewModel, 6h in DiscoverViewModel). Cold launches always hit network.
