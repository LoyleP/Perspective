import Foundation

enum AppConfig {
    // MARK: - Supabase Configuration
    // Note: These are public-facing anon keys, protected by RLS policies on server
    // For production, consider moving to environment variables or secure configuration

    static let supabaseURL = "https://lsznkuiaowesucmxwwfi.supabase.co"
    static let supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imxzem5rdWlhb3dlc3VjbXh3d2ZpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQwODQ0NjYsImV4cCI6MjA4OTY2MDQ2Nn0.llsAgcjoJHI9VVZjl8PL0k_HDJhUEzrLjxH5r9TgNgQ"

    // MARK: - StoreKit Configuration
    // Product IDs must match App Store Connect configuration
    static let monthlySubscriptionID = "perspective.premium.monthly"
    static let annualSubscriptionID = "perspective.premium.annual"
}
