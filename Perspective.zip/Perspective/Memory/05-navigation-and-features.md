# Navigation & Features

## Tab Structure

```
TabView (iOS 18 modern Tab API / legacy fallback)
├── Tab 0: "À la une" (Feed)              — custom AppLogoTab image
│   └── NavigationStack
│       └── FeedView → StoryDetailView
│           ├── StoryThreadView (chronological timeline)
│           ├── SourcesView (ownership)
│           └── ArticleBrowserView (WebKit modal, records reading history)
│
├── Tab 1: "Alertes" (Notifications)       — bell icon
│   └── AlertesView (owns its own NavigationStack for deep-link)
│       └── StoryDetailView
│
├── Tab 2: "Profil"                        — person icon
│   └── NavigationStack
│       └── ProfileView
│           ├── SavedView (bookmarks)
│           └── SourcesView → SourceDetailView
│
├── Tab 3: Discover (search role)          — iOS 18 .search role
│   └── NavigationStack
│       └── DiscoverView → StoryDetailView
│
Sheets/Overlays:
├── SettingsView (sheet from ProfileView toolbar)
│   └── MySpectrumView (NavigationLink)
├── PaywallView (full-screen sheet, after 5 stories)
├── PaywallBannerView (bottom banner, non-blocking)
└── OnboardingView (full-screen cover, first launch)
```

**Note:** Legacy tab view (pre-iOS 18) has different tab ordering — Discover at tab 1, Alertes at tab 2, Profil at tab 3.

## Deep-Link Flow

1. Notification tapped → `NotificationManager.pendingStoryID` set
2. `RootView.onChange(of: pendingStoryID)` switches to Alertes tab
3. `AlertesView` picks up `pendingStoryID` and navigates to `StoryDetailView`

## Key Features

### 1. News Feed (`FeedView` + `FeedViewModel`)
- Hero card: `cetteSemanineHero` — prefers `isFeatured`, falls back to first story
- Aggregate coverage bar: `FeedCoverageBarView` using `CoverageStats.aggregate()` across all feed stories
- Daily brief: 2-story horizontal carousel (`DailyBriefSectionView`)
- Paginated story list: `StoryCardView` in 3 variants (big, small, extended)
- Stories filtered to ≥2 articles, sorted by `lastUpdatedAt DESC`

### 2. Political Spectrum Analysis
- Per-story: `CoverageChartView` — bar chart with 7-point breakdown
- Per-story: `CoverageTagsView` — top 2 lean positions by percentage
- Feed-level: `FeedCoverageBarView` — compact stacked bar + dynamic narrative

### 3. AI Summaries (`SpectrumSummaryView` + `StoryDetailViewModel`)
- On-demand generation via Gemini Edge Function
- Per-perspective narrative showing how each political position covers the story
- Skeleton loader while waiting, perspectives list when available

### 4. In-App Article Reader (`ArticleBrowserView`)
- WebKit `WKWebView` in-app browser
- Auto-hiding toolbar
- Records reading history after 2 seconds (lean value → `ReadingHistoryStore`)

### 5. Media Ownership Transparency
- `OwnershipBreakdownView` — shows who owns each source covering a story
- `OwnershipSection` — groups by owner with info sheet
- `SourceDetailView` — individual source info: logo, lean, owner, recent articles

### 6. Reading History (`MySpectrumView` + `ReadingHistoryStore`)
- Tracks which political positions user reads most
- Spectrum bar showing distribution
- Breakdown list sorted by frequency
- Reset functionality

### 7. Search & Discover (`DiscoverView` + `DiscoverViewModel`)
- Topic filter chips: 8 categories (Tout, Politique, Économie, etc.)
- Server-side topic filter via Supabase `contains()` on `topic_tags`
- Client-side text search on `story.title`
- Sorted by article count DESC
- Pagination with `loadMore()`

### 8. Push Notifications (`AlertesView` + `NotificationManager`)
- Polls Supabase `notifications` table on app active
- Schedules local notifications for new entries
- Notification list with deep-link navigation to stories

### 9. Bookmarks (`SavedView` + `BookmarkStore`)
- Toggle bookmark on any story
- Persisted as JSON-encoded `[Story]` in UserDefaults
- Inserted at position 0 (most recent first)

### 10. Soft Paywall
- `SessionState.storiesOpened` counter (in-memory, resets per launch)
- After 5 opens: `PaywallView` full-screen sheet
- `PaywallBannerView` non-blocking bottom banner
- Premium unlocks via StoreKit 2 subscription
- DEBUG: `devIsPremium` AppStorage toggle

### 11. Onboarding
- `OnboardingView` — first-launch flow
- Controlled by `@AppStorage("hasCompletedOnboarding")`

### 12. Dark Mode
- Full adaptive color system via `AppColors.Adaptive`
- Theme controlled by `@AppStorage("colorSchemeRaw")`: 0=system, 1=light, 2=dark
