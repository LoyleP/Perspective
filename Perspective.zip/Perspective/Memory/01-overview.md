# Perspective+ — Project Overview

## What It Is

French news aggregation app. Shows how stories get covered across a **7-point political spectrum** (extrême-gauche → extrême-droite). Think "Ground News" but for French media. AI-generated summaries (via Gemini) break down narratives per political position. Freemium model with StoreKit 2 subscriptions.

## Tech Stack

- **Platform:** iOS 17+, SwiftUI-only, Swift 5.9+
- **Backend:** Supabase (PostgREST + Edge Functions + pg_cron)
- **AI:** Gemini via Supabase Edge Function `generate-spectrum-summary`
- **Monetization:** StoreKit 2 auto-renewable subscriptions
- **Dependencies:** Supabase Swift SDK (SPM). No CocoaPods, no third-party UI/networking libs.
- **Native frameworks:** SwiftUI, Foundation, StoreKit, WebKit, UserNotifications, OSLog, CoreText

## Architecture

**MVVM strict.** View → ViewModel → Repository → Service.

- `@Observable` everywhere (no `ObservableObject`, no `@StateObject`)
- `@MainActor` on all ViewModels and UI-touching services
- `async/await` throughout, zero Combine, zero completion handlers
- `@Environment` for DI — `SessionState`, `BookmarkStore`, `ReadingHistoryStore` injected at root via `RootView`
- `NavigationStack` with typed paths
- Protocol-based repository injection (`StoryRepositoryProtocol`, `SourceRepositoryProtocol`) — all ViewModels accept mock repositories via init

## File Count

~76 Swift files. 20+ views, 6 ViewModels, 4 services, 2 repositories, 9 models, 13+ UI components, 7 test files.

## Bundle ID

`com.flow.perspective`

## Known Singletons

- `SupabaseService.shared` — Supabase client init (acceptable for portfolio scope)
- `StoryRepository.shared` / `SourceRepository.shared` — default instances, overridable via protocol injection
- `NotificationManager.shared` — push/local notification handling
