# Known Issues & Limitations

## Architecture

- **`SupabaseService.shared` singleton** — not protocol-injected. Acceptable for portfolio scope but makes testing Supabase-dependent code harder.
- **`StoryDetailViewModel` bypasses repository layer** — calls Supabase Edge Function directly for summary generation. Intentional: single-use call, no protocol needed.
- **`NotificationManager.shared` singleton** — not injectable. Polls Supabase directly in `checkForNewStories()`.

## Data

- **Feed cache is in-memory only** — cold launches always hit network. FeedViewModel uses 48h TTL, DiscoverViewModel uses 6h TTL.
- **Reading history is unbounded `[Int]`** — no cap on growth. Over time this array in UserDefaults could get large.
- **Bookmarks store full `[Story]` objects** — JSON-encoded in UserDefaults. Could grow large with many bookmarks (each Story includes articles + coverage).

## UI

- **`ArticlesSection` and `OwnershipSection` use system fonts** — legacy components not yet migrated to design token typography (`Typography.swift`).
- **Legacy tab view has different tab ordering** — pre-iOS 18 fallback puts Discover at tab 1, Alertes at tab 2. Modern tab view has Alertes at tab 1, Discover at tab 3 (search role).

## Testing

- **No tests for:** `StoryDetailViewModel`, `StoreManager`, `NotificationManager`, `ReadingHistoryStore`, any views.
- **UI test stubs are empty** — `PerspectiveUITests/` files exist but contain no real tests.

## Performance

- **No pagination prefetch** — DiscoverViewModel loads on scroll but FeedViewModel loads all 30 stories at once.
- **No image caching** — relies on system URLCache via AsyncImage. No dedicated `ImageCacheService`.
- **StoryDetailViewModel.triggerSummaryGeneration()** uses fixed 3-second `Task.sleep` — no polling or websocket for real-time updates.

## Resolved Issues (2026-05-28)

- **Notification decoding failure** — `NotificationManager.fetchNotifications()` and `checkForNewStories()` used a manual `JSONDecoder` with basic `.iso8601` that couldn't handle Supabase's fractional-seconds timestamps. Fixed: now uses `.execute().value` which leverages SupabaseService's custom decoder.
- **Authorization status race condition** — `AlertesViewModel.init()` read `NotificationManager.authorizationStatus` synchronously before the async init Task updated it. Fixed: `load()` now re-checks authorization status before fetching.
- **Notifications missing `story_id`** — The `notifications` table originally had no `story_id` column. The trigger `notify_new_stories()` stored the top story title but not its ID. Fixed: added `story_id UUID REFERENCES stories(id)` column, updated trigger to populate it, backfilled existing rows by title match.
- **Cron job failing (null URL)** — `pg_cron` job read `project_url` and `anon_key` from `vault.decrypted_secrets` but secrets were never inserted. Every run failed with null URL/Authorization. Fixed: inserted both secrets into Vault.
