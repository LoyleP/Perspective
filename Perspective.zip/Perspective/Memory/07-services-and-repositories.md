# Services & Repositories

## Repository Layer

### StoryRepositoryProtocol (`Core/Protocols/RepositoryProtocols.swift`)
```swift
protocol StoryRepositoryProtocol: Sendable {
    func fetchFeed(topic: String?, limit: Int, offset: Int) async throws -> [Story]
    func fetchStory(id: UUID) async throws -> Story?
}
```

### SourceRepositoryProtocol
```swift
protocol SourceRepositoryProtocol: Sendable {
    func fetchAllSources() async throws -> [Source]
    func fetchSource(id: UUID) async throws -> Source?
    func fetchRecentArticles(sourceId: UUID, limit: Int) async throws -> [Article]
}
```

### StoryRepository (`Core/Repositories/StoryRepository.swift`)
- Singleton: `StoryRepository.shared`
- Uses `SupabaseService.shared.client` for all queries
- `fullSelect = "*, story_coverage_view(*), articles!inner(*, sources(*))"`
- `fetchFeed`: optional topic filter via `contains("topic_tags", "{topic}")`, ordered `last_updated_at DESC, id ASC`, paginated with `range(from:to:)`
- `fetchStory`: by UUID, limit 1
- Errors mapped to `AppError.from(error)`

### SourceRepository (`Core/Repositories/SourceRepository.swift`)
- Singleton: `SourceRepository.shared`
- `fetchAllSources`: active sources ordered by `political_lean ASC`
- `fetchSource`: by UUID, limit 1
- `fetchRecentArticles`: by `source_id`, ordered `published_at DESC`

## Service Layer

### SupabaseService (`Core/Services/SupabaseService.swift`)
- Singleton: `SupabaseService.shared`
- Creates `SupabaseClient` with:
  - Custom `JSONDecoder` handling 3 date formats: ISO8601 with fractional seconds, ISO8601 without, date-only yyyy-MM-dd
  - Auth options: `emitLocalSessionAsInitialSession: true`
- Config from `AppConfig.supabaseURL` and `AppConfig.supabaseAnonKey`

### StoreManager (`Core/Services/StoreManager.swift`)
- `@MainActor @Observable`
- Product IDs: `perspective.premium.monthly`, `perspective.premium.annual`
- State: `products: [Product]`, `purchasedSubscriptions: Set<String>`, `isLoading`, `error: AppError?`
- `isPremium: Bool` — true if any active subscription
- `loadProducts()` — fetches from App Store
- `purchase(_ product:)` — purchase flow with verification
- `restorePurchases()` — `AppStore.sync()` + status update
- Background `Transaction.updates` listener via `Task.detached`
- `checkVerified()` — nonisolated static, throws `StoreError.failedVerification` on unverified
- Helpers: `monthlyProduct`, `annualProduct`

### NotificationManager (`Core/Services/NotificationManager.swift`)
- `@MainActor @Observable`, singleton, `NSObject` subclass (for `UNUserNotificationCenterDelegate`)
- State: `authorizationStatus`, `pendingStoryID` (for deep-link)
- `requestAuthorization()` — requests `.alert`, `.badge`, `.sound`
- `checkForNewStories()` — polls Supabase `notifications` table, compares with `lastNotificationId` in UserDefaults, schedules local notification if new
- `fetchNotifications()` — returns last 50 notifications
- Delegate methods: `willPresent` shows banner+sound+badge, `didReceive` extracts `story_id` and sets `pendingStoryID`

### ReadingHistoryStore (`Core/Services/ReadingHistoryStore.swift`)
- `@MainActor @Observable`
- Tracks `[Int]` lean values in UserDefaults key `readingHistory`
- `record(lean:)` — appends lean value
- `reset()` — clears array
- `breakdown` computed: groups by lean 1-7, returns sorted by count DESC

## Dependency Injection Pattern

ViewModels accept repository via init with default:
```swift
init(repository: any StoryRepositoryProtocol = StoryRepository.shared) {
    self.repository = repository
}
```

Environment objects injected at `RootView`:
```swift
.environment(session)       // SessionState
.environment(bookmarks)     // BookmarkStore
.environment(readingHistory) // ReadingHistoryStore
```

## Logging (`Core/Utilities/Log.swift`)

```swift
enum Log {
    static let feed         = Logger(category: "Feed")
    static let story        = Logger(category: "Story")
    static let repository   = Logger(category: "Repository")
    static let store        = Logger(category: "Store")
    static let notification = Logger(category: "Notification")
    static let general      = Logger(category: "General")
}
```

Subsystem: `Bundle.main.bundleIdentifier ?? "com.perspective"`
