# Testing

## Framework

**Swift Testing** (`@Test`, `#expect`, `@Suite`) — not XCTest.

## Test Suites (20 tests, 4 suites)

### FeedViewModelTests (6 tests)
File: `PerspectiveTests/FeedViewModelTests.swift`

All tests are `@MainActor`. Uses `MockStoryRepository`.

| Test | What It Verifies |
|------|------------------|
| `loadFetchesStories` | Stories loaded from repo, no error, loading reset, call count = 1 |
| `loadSetsError` | URLError(.notConnectedToInternet) → `AppError.networkUnavailable` |
| `loadSkipsWhenCacheFresh` | Second load() doesn't call repo again (48h cache) |
| `refreshClearsCacheAndReloads` | refresh() clears cache, second fetch happens |
| `storiesFiltersMinArticles` | Stories with <2 articles filtered out of `stories` computed |
| `heroPrefersFeatured` | `cetteSemanineHero` returns featured story over regular |

### DiscoverViewModelTests (4 tests)
File: `PerspectiveTests/DiscoverViewModelTests.swift`

Tests topic toggle logic, search filtering, error handling.

### BookmarkStoreTests (3 tests)
File: `PerspectiveTests/BookmarkStoreTests.swift`

Tests toggle on/off, `isBookmarked()`, insert-at-0 order. Uses isolated `UserDefaults(suiteName:)`.

### AppErrorTests (7 tests)
File: `PerspectiveTests/AppErrorTests.swift`

Tests `AppError.from()` mapping: NSURLError codes → specific cases, DecodingError → `.dataCorrupted`, Equatable conformance.

## Test Support Files

### MockStoryRepository (`PerspectiveTests/Mocks/MockStoryRepository.swift`)
```swift
final class MockStoryRepository: StoryRepositoryProtocol, @unchecked Sendable {
    var feedResult: Result<[Story], Error> = .success([])
    var storyResult: Result<Story?, Error> = .success(nil)
    var fetchFeedCallCount = 0
    var lastFetchTopic: String?
    var lastFetchLimit: Int?
    var lastFetchOffset: Int?
}
```

### TestData (`PerspectiveTests/Helpers/TestData.swift`)
Factory methods:
- `makeArticle(id:sourceID:title:isPrimary:politicalLean:)` — creates Article with embedded Source
- `makeStory(id:title:articleCount:isFeatured:)` — creates Story with N articles

Fixed IDs: `storyID = "00000000-0000-0000-0000-000000000001"`, `sourceID = "10000000-0000-0000-0000-000000000001"`

## Testing Patterns

- Protocol-based DI: ViewModels accept `any StoryRepositoryProtocol`, tests inject `MockStoryRepository`
- `Result` type for mock configuration: `feedResult: Result<[Story], Error>`
- Call counting: `fetchFeedCallCount` for cache verification
- `@MainActor @Suite` for all ViewModel tests (required because ViewModels are `@MainActor`)
- `BookmarkStoreTests` uses `UserDefaults(suiteName: "test-suite-name")` for isolation

## What's Not Tested

- UI tests exist as stubs (`PerspectiveUITests/`) but are empty
- `StoryDetailViewModel` (direct Supabase call, no protocol)
- `StoreManager` (StoreKit requires sandbox)
- `NotificationManager` (singleton, side effects)
- `ReadingHistoryStore` (no existing tests)
- Views (no snapshot or UI tests)
